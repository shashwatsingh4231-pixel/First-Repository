# Creating a tuple
numbers = (5, 2, 9, 1, 7)

# Finding max and min
print("Maximum:", max(numbers))
print("Minimum:", min(numbers))