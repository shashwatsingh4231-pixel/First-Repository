#division
a = int(input("enter the num1 :"))
b = int(input("enter the num2 :"))
def div(a, b):
  return a / b
print("The division of two numbers is:", div(a, b))
-- ./main.py