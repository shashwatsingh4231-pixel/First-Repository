#Sum
a = int(input("Enter the num1: "))
b = int(input("Enter the num2:"))

def summ(a, b):

  return a + b



print("The sum of two numbers is:", summ(a, b))
