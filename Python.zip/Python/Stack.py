# Stack using list
stack = []
# Push elements
stack.append(10)
stack.append(20)
stack.append(30)
print("Stack after push:", stack)
# Pop element
stack.pop()
print("Stack after pop:", stack)