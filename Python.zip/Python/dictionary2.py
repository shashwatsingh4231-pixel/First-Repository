# Simple Student Record using Dictionary

students = {}

# Add 3 students
for i in range(3):
    roll = input("Enter roll number: ")
    name = input("Enter name: ")
    students[roll] = name

# Display all students
print("\nStudent Records:")
for roll in students:
    print("Roll No:", roll, "Name:", students[roll])

# Search a student
search = input("\nEnter roll number to search: ")

if search in students:
    print("Student found:", students[search])
else:
    print("Student not found")
    