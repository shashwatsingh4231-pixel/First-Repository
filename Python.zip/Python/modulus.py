#modulus
a = int(input("enter the num1"))
b= INT(input("Enter the num2:"))
def mod(a,b):
  return a%b
print("The modulus of two numbers is:", mod(a, b))
