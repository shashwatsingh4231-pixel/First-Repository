#multiply
a = int(input("Enter the num1:"))
b = int(input("Enter the num2:"))
def multiply(a, b):
   return a * b   #return the product of a and b  
print("The product of two numbers is:", multiply(a, b))   #print the product of a and b
