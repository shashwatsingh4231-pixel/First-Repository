def add(a, b):
  return a + b

def subtract(a, b):
  return a - b

def multiply(a, b):
  return a * b

def divide(a, b):
  return a / b if b != 0 else "Cannot divide by zero"

# Dictionary mapping
operations = {
  '+': add,
  '-': subtract,
  '*': multiply,
  '/': divide
}

# User input
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))
op = input("Enter operation (+, -, *, /): ")

# Perform operation using dictionary
if op in operations:
  result = operations[op](a, b)
  print("Result:", result)
else:
  print("Invalid operation")