numbers = (10, 20, 30, 40)

# Printing tuple
print("Tuple elements are:")
for num in numbers:
    print(num)