#difference
a = int(input("Enter the num1: "))
b = int(input("Enter the num2:"))
def diff(a, b):
   return a - b
c= diff(a,b)
print("The difference of two numbers is:", c)
  